
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	export interface AppTypes {
		RouteId(): "/" | "/analytics" | "/auto-scaling" | "/blue-green" | "/certificates" | "/configuration" | "/control" | "/deployment-portal-test" | "/deployment-portal" | "/deployments" | "/logs" | "/multi-cloud" | "/security";
		RouteParams(): {
			
		};
		LayoutParams(): {
			"/": Record<string, never>;
			"/analytics": Record<string, never>;
			"/auto-scaling": Record<string, never>;
			"/blue-green": Record<string, never>;
			"/certificates": Record<string, never>;
			"/configuration": Record<string, never>;
			"/control": Record<string, never>;
			"/deployment-portal-test": Record<string, never>;
			"/deployment-portal": Record<string, never>;
			"/deployments": Record<string, never>;
			"/logs": Record<string, never>;
			"/multi-cloud": Record<string, never>;
			"/security": Record<string, never>
		};
		Pathname(): "/" | "/analytics" | "/analytics/" | "/auto-scaling" | "/auto-scaling/" | "/blue-green" | "/blue-green/" | "/certificates" | "/certificates/" | "/configuration" | "/configuration/" | "/control" | "/control/" | "/deployment-portal-test" | "/deployment-portal-test/" | "/deployment-portal" | "/deployment-portal/" | "/deployments" | "/deployments/" | "/logs" | "/logs/" | "/multi-cloud" | "/multi-cloud/" | "/security" | "/security/";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/circuitBreakerConfig.json" | "/robots.txt" | string & {};
	}
}