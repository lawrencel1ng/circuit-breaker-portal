# OCBC Circuit Breaker Management Portal

A comprehensive Circuit Breaker Management Portal demo built with SvelteKit, showcasing F5 resiliency architecture for OCBC's multi-lane traffic management system.

## Features

### 🏗️ Architecture Overview
- **Multi-lane traffic management** with circuit breakers at two levels:
  - Edge Circuit Breaker (GSLB): Routes incoming traffic to the correct edge lane
  - Enterprise Circuit Breaker (GSLB): Routes traffic from edge servers to enterprise server farm lanes
- **3 traffic lanes** (Lane 1, Lane 2, Lane 3) each containing:
  - Edge Load Balancer
  - Edge Servers
  - Enterprise Load Balancer
  - Enterprise Servers (multiple deployments per lane)

### 📊 Dashboard Features
- **Lane Overview Dashboard**: Visual representation of all 3 lanes with real-time status
- **Traffic Flow Diagram**: Animated diagram showing Client → Edge → Enterprise flow
- **Quick Stats**: Overview of lanes, deployments, and server health
- **Recent Activity**: Real-time log of system events

### 🎛️ Control Panel
- **Lane Control**: Toggle switches for Edge and Enterprise circuit breakers
- **Quick Actions**: Activate all lanes, failover to specific lanes, maintenance mode
- **Global Settings**: Health check intervals, circuit breaker thresholds, auto-failover
- **Flip Down Lane**: Manual lane closure with confirmation modal

### 🚀 Application Deployment Manager
- **Deploy Applications**: Form to deploy new applications across lanes
- **Deployment Types**: Virtual Servers, Pool Members, Wide IPs
- **Deployment History**: Track all application deployments
- **Rollback Functionality**: Easy rollback of deployments

### ⚙️ Configuration Manager
- **Load Balancer Settings**: Virtual server and pool management per lane
- **GSLB Settings**: Wide IP and pool configurations
- **Health Check Settings**: Configurable health monitoring
- **Load Balancing Methods**: Round Robin, Ratio, etc.

### 📋 Automation Log Viewer
- **Real-time Logs**: Monitor all configuration changes and system events
- **Advanced Filtering**: Filter by timestamp, lane, action type, user
- **Export Functionality**: Export logs to CSV
- **Search**: Full-text search across log entries

### 🔄 Automation Logic
- **Lane Flip-Down Workflow**: Automated lane closure process
- **Application Deployment Workflow**: Automated deployment across selected lanes
- **Health-Based Auto Circuit Breaking**: Automatic circuit breaker triggers
- **Real-time Health Monitoring**: Continuous health checks every 10 seconds

## Technology Stack

- **Frontend**: SvelteKit with TypeScript
- **Styling**: TailwindCSS with custom design system
- **Icons**: Lucide Svelte
- **Charts**: Chart.js (ready for implementation)
- **State Management**: Svelte stores
- **Persistence**: Local JSON file storage

## Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd circuit-breaker-portal
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and navigate to `http://localhost:5173`

### Building for Production

```bash
npm run build
npm run preview
```

## Project Structure

```
src/
├── lib/
│   ├── components/          # Reusable UI components
│   ├── stores/             # Svelte stores for state management
│   ├── types.ts            # TypeScript type definitions
│   └── utils/              # Utility functions
├── routes/                 # SvelteKit routes
│   ├── +page.svelte       # Dashboard
│   ├── control/           # Control Panel
│   ├── deployments/       # Application Deployments
│   ├── configuration/     # Configuration Manager
│   └── logs/              # Automation Logs
└── app.html               # HTML template
```

## Key Components

### Dashboard Components
- `LaneCard.svelte`: Individual lane status display
- `TrafficFlowDiagram.svelte`: Visual traffic flow representation
- `QuickStats.svelte`: System overview statistics
- `RecentLogs.svelte`: Recent activity feed

### Control Panel Components
- `LaneControl.svelte`: Lane-specific controls
- `QuickActions.svelte`: System-wide quick actions
- `GlobalSettings.svelte`: Global configuration settings

### Deployment Components
- `DeploymentForm.svelte`: Application deployment form
- `DeploymentList.svelte`: List of deployed applications

### Configuration Components
- `LoadBalancerConfig.svelte`: Load balancer configuration
- `GSLBConfig.svelte`: GSLB configuration management

### Utility Components
- `NotificationContainer.svelte`: Toast notification system
- `NotificationStore.svelte`: Notification state management

## Data Model

The application uses a comprehensive JSON data structure stored in `static/circuitBreakerConfig.json`:

```typescript
interface CircuitBreakerConfig {
  lanes: Lane[];
  applications: Application[];
  automationLogs: AutomationLog[];
  globalSettings: GlobalSettings;
}
```

## Features in Detail

### Real-time Updates
- Simulated health check updates every 10 seconds
- Real-time status indicators
- Live traffic distribution updates

### Responsive Design
- Mobile-first approach
- Dark mode support
- Tablet and desktop optimized

### Notification System
- Toast notifications for user actions
- Success, error, warning, and info message types
- Auto-dismiss with configurable duration

### Accessibility
- Keyboard navigation support
- Screen reader friendly
- High contrast mode support

## Demo Scenarios

1. **Lane Management**: Toggle lanes on/off, flip down lanes
2. **Application Deployment**: Deploy applications across multiple lanes
3. **Configuration Management**: Modify load balancer and GSLB settings
4. **Health Monitoring**: Watch real-time health status updates
5. **Log Analysis**: Filter and export automation logs

## Future Enhancements

- Role-based access control (Admin vs Operator views)
- Configuration diff viewer
- Scheduled maintenance windows
- Bulk operations
- Configuration templates/presets
- Audit trail with user tracking
- Real F5 BIG-IP API integration
- WebSocket for real-time updates

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For questions or support, please contact the development team or create an issue in the repository.
