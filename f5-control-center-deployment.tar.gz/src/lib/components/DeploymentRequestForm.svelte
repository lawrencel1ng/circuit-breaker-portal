<script lang="ts">
  import { Send, Shield, Server, Globe, Zap } from 'lucide-svelte';

  let formData = {
    developer: 'john.doe@ocbc.com',
    applicationName: '',
    applicationType: 'web' as 'web' | 'api' | 'tcp' | 'udp',
    securityLevel: 'medium' as 'low' | 'medium' | 'high' | 'critical',
    environment: 'staging' as 'development' | 'staging' | 'production',
    description: ''
  };

  let isSubmitting = false;

  function getSecurityLevelColor(level: string) {
    switch (level) {
      case 'low': return 'text-green-600 bg-green-100 dark:bg-green-900 dark:text-green-200';
      case 'medium': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-200';
      case 'high': return 'text-orange-600 bg-orange-100 dark:bg-orange-900 dark:text-orange-200';
      case 'critical': return 'text-red-600 bg-red-100 dark:bg-red-900 dark:text-red-200';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900 dark:text-gray-200';
    }
  }

  function getApplicationTypeIcon(type: string) {
    switch (type) {
      case 'web': return Globe;
      case 'api': return Zap;
      case 'tcp': return Server;
      case 'udp': return Server;
      default: return Server;
    }
  }

  function handleSubmit() {
    console.log('Form submitted:', formData);
    isSubmitting = true;
    setTimeout(() => {
      isSubmitting = false;
    }, 2000);
  }

</script>

<div class="max-w-4xl mx-auto">
  <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
    <!-- Header -->
    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
      <h2 class="text-xl font-semibold text-gray-900 dark:text-white">
        Request New Deployment
      </h2>
      <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">
        Fill out the form below to request a new F5 load balancer service deployment
      </p>
    </div>

    <!-- Form -->
    <form on:submit|preventDefault={handleSubmit} class="p-6 space-y-6">
      <!-- Developer Info -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label for="developer" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Developer Email
          </label>
          <input
            id="developer"
            type="email"
            bind:value={formData.developer}
            required
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:text-white"
            placeholder="developer@ocbc.com"
          />
        </div>

        <div>
          <label for="app-name" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Application Name
          </label>
          <input
            id="app-name"
            type="text"
            bind:value={formData.applicationName}
            required
            class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:text-white"
            placeholder="e.g., OCBC Mobile Banking API"
          />
        </div>
      </div>

      <!-- Application Type -->
      <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
          Application Type
        </label>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
          {#each ['web', 'api', 'tcp', 'udp'] as type}
            {@const Icon = getApplicationTypeIcon(type)}
            <div 
              class="relative cursor-pointer"
              on:click={() => formData.applicationType = type}
              role="button"
              tabindex="0"
              on:keydown={(e) => e.key === 'Enter' && (formData.applicationType = type)}
            >
              <input
                type="radio"
                bind:group={formData.applicationType}
                value={type}
                class="sr-only"
              />
              <div class="flex flex-col items-center p-4 border-2 rounded-lg transition-all duration-200
                {formData.applicationType === type 
                  ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' 
                  : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'}"
              >
                <Icon class="h-6 w-6 mb-2 {formData.applicationType === type ? 'text-blue-600' : 'text-gray-400'}" />
                <span class="text-sm font-medium {formData.applicationType === type ? 'text-blue-900 dark:text-blue-100' : 'text-gray-700 dark:text-gray-300'}">
                  {type.toUpperCase()}
                </span>
              </div>
            </div>
          {/each}
        </div>
      </div>

      <!-- Security Level -->
      <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
          Security Level
        </label>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
          {#each ['low', 'medium', 'high', 'critical'] as level}
            <div 
              class="relative cursor-pointer"
              on:click={() => formData.securityLevel = level}
              role="button"
              tabindex="0"
              on:keydown={(e) => e.key === 'Enter' && (formData.securityLevel = level)}
            >
              <input
                type="radio"
                bind:group={formData.securityLevel}
                value={level}
                class="sr-only"
              />
              <div class="flex flex-col items-center p-4 border-2 rounded-lg transition-all duration-200
                {formData.securityLevel === level 
                  ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' 
                  : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'}"
              >
                <Shield class="h-6 w-6 mb-2 {formData.securityLevel === level ? 'text-blue-600' : 'text-gray-400'}" />
                <span class="text-sm font-medium {formData.securityLevel === level ? 'text-blue-900 dark:text-blue-100' : 'text-gray-700 dark:text-gray-300'}">
                  {level.charAt(0).toUpperCase() + level.slice(1)}
                </span>
                <div class="mt-1 px-2 py-1 rounded-full text-xs {getSecurityLevelColor(level)}">
                  {level === 'low' && 'Basic SSL'}
                  {level === 'medium' && 'SSL + Basic WAF'}
                  {level === 'high' && 'SSL + Advanced WAF'}
                  {level === 'critical' && 'SSL + WAF + DDoS'}
                </div>
              </div>
            </div>
          {/each}
        </div>
      </div>

      <!-- Environment -->
      <div>
        <label for="environment" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Environment
        </label>
        <select
          id="environment"
          bind:value={formData.environment}
          class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:text-white"
        >
          <option value="development">Development</option>
          <option value="staging">Staging</option>
          <option value="production">Production</option>
        </select>
      </div>

      <!-- Description -->
      <div>
        <label for="description" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Description
        </label>
        <textarea
          id="description"
          bind:value={formData.description}
          rows="3"
          class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:text-white"
          placeholder="Describe your application and its requirements..."
        ></textarea>
      </div>

      <!-- What will be created -->
      <div class="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
        <h3 class="text-sm font-medium text-gray-900 dark:text-white mb-3">
          What will be automatically created:
        </h3>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div class="flex items-center space-x-2">
            <div class="w-2 h-2 bg-green-500 rounded-full"></div>
            <span class="text-gray-700 dark:text-gray-300">Virtual Server (VIP)</span>
          </div>
          <div class="flex items-center space-x-2">
            <div class="w-2 h-2 bg-green-500 rounded-full"></div>
            <span class="text-gray-700 dark:text-gray-300">Load Balancer Pool</span>
          </div>
          <div class="flex items-center space-x-2">
            <div class="w-2 h-2 bg-green-500 rounded-full"></div>
            <span class="text-gray-700 dark:text-gray-300">SSL Profile</span>
          </div>
          <div class="flex items-center space-x-2">
            <div class="w-2 h-2 bg-green-500 rounded-full"></div>
            <span class="text-gray-700 dark:text-gray-300">WAF Policy</span>
          </div>
          <div class="flex items-center space-x-2">
            <div class="w-2 h-2 bg-green-500 rounded-full"></div>
            <span class="text-gray-700 dark:text-gray-300">Health Monitors</span>
          </div>
          <div class="flex items-center space-x-2">
            <div class="w-2 h-2 bg-green-500 rounded-full"></div>
            <span class="text-gray-700 dark:text-gray-300">Monitoring Dashboard</span>
          </div>
        </div>
      </div>

      <!-- Submit Button -->
      <div class="flex justify-end">
        <button
          type="submit"
          disabled={isSubmitting}
          class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {#if isSubmitting}
            <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
              <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Submitting...
          {:else}
            <Send class="h-5 w-5 mr-2" />
            Submit Deployment Request
          {/if}
        </button>
      </div>
    </form>
  </div>
</div>