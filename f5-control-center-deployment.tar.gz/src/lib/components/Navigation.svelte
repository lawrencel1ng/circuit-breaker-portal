<script lang="ts">
  import { page } from '$app/stores';
  import { Moon, Sun, Settings, Activity, Server, Globe, Shield, BarChart, Zap, TrendingUp, FileText, ChevronDown, ChevronRight } from 'lucide-svelte';

  export let darkMode: boolean;
  export let toggleDarkMode: () => void;

  let openDropdowns = {
    onPremises: false,
    cloud: false,
    security: false,
    analytics: false
  };

  const navigation = [
    { 
      name: 'Dashboard', 
      href: '/', 
      icon: Activity,
      type: 'single'
    },
    { 
      name: 'On-Premises', 
      icon: Server,
      type: 'dropdown',
      key: 'onPremises',
      items: [
        { name: 'F5 Deployments', href: '/deployment-portal', icon: Server },
        { name: 'Blue/Green', href: '/blue-green', icon: Zap },
        { name: 'Circuit Breakers', href: '/control', icon: Settings },
        { name: 'Certificates', href: '/certificates', icon: FileText }
      ]
    },
    { 
      name: 'Cloud Services', 
      icon: Globe,
      type: 'dropdown',
      key: 'cloud',
      items: [
        { name: 'Multi-Cloud', href: '/multi-cloud', icon: Globe },
        { name: 'Auto-Scaling', href: '/auto-scaling', icon: TrendingUp }
      ]
    },
    { 
      name: 'Security', 
      href: '/security', 
      icon: Shield,
      type: 'single'
    },
    { 
      name: 'Analytics', 
      href: '/analytics', 
      icon: BarChart,
      type: 'single'
    }
  ];

  function toggleDropdown(key: string) {
    openDropdowns[key] = !openDropdowns[key];
  }

  function isCurrentPage(href: string) {
    return $page.url.pathname === href;
  }

  function isDropdownActive(items: any[]) {
    return items.some(item => isCurrentPage(item.href));
  }

  function closeAllDropdowns() {
    openDropdowns = {
      onPremises: false,
      cloud: false,
      security: false,
      analytics: false
    };
  }
</script>

<nav class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700" on:click|self={closeAllDropdowns}>
  <div class="container mx-auto px-4">
    <div class="flex justify-between items-center h-16">
      <!-- Logo and Title -->
      <div class="flex items-center space-x-6">
        <div class="flex items-center space-x-3">
          <img 
            src="https://www.temenos.com/wp-content/uploads/2025/04/Logo_NTT-DATA_1024X576PX-768x432-1.png" 
            alt="NTT Data Logo" 
            class="h-10 w-auto"
          />
          <div class="flex items-center space-x-2">
            <h1 class="text-xl font-bold text-gray-900 dark:text-white">
              F5 Automation Control Center
            </h1>
          </div>
          <div class="flex items-center space-x-4 mt-1">
            <div class="flex items-center space-x-2">
              <div class="w-2 h-2 bg-green-500 rounded-full"></div>
              <span class="text-xs text-gray-600 dark:text-gray-400">Ready to Integrate</span>
            </div>
            <div class="flex items-center space-x-2">
              <div class="w-2 h-2 bg-yellow-500 rounded-full"></div>
              <span class="text-xs text-gray-600 dark:text-gray-400">Phase 2</span>
            </div>
            <div class="flex items-center space-x-2">
              <div class="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span class="text-xs text-gray-600 dark:text-gray-400">Future Roadmap</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Navigation Links -->
      <div class="hidden md:flex space-x-1">
        {#each navigation as item}
          {#if item.type === 'single'}
            <a
              href={item.href}
              class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200
                {isCurrentPage(item.href)
                  ? 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-200'
                  : 'text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700'}"
            >
              <svelte:component this={item.icon} class="h-4 w-4" />
              <span>{item.name}</span>
            </a>
          {:else if item.type === 'dropdown'}
            <div class="relative">
              <button
                on:click={() => toggleDropdown(item.key)}
                class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200
                  {isDropdownActive(item.items)
                    ? 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-200'
                    : 'text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700'}"
              >
                <svelte:component this={item.icon} class="h-4 w-4" />
                <span>{item.name}</span>
                <svelte:component this={openDropdowns[item.key] ? ChevronDown : ChevronRight} class="h-3 w-3" />
              </button>
              
              {#if openDropdowns[item.key]}
                <div class="absolute top-full left-0 mt-1 w-56 bg-white dark:bg-gray-800 rounded-md shadow-lg border border-gray-200 dark:border-gray-700 z-50">
                  <div class="py-1">
                    {#each item.items as subItem}
                      <a
                        href={subItem.href}
                        class="flex items-center space-x-3 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200
                          {isCurrentPage(subItem.href) ? 'bg-primary-50 text-primary-700 dark:bg-primary-900 dark:text-primary-200' : ''}"
                      >
                        <svelte:component this={subItem.icon} class="h-4 w-4" />
                        <span>{subItem.name}</span>
                      </a>
                    {/each}
                  </div>
                </div>
              {/if}
            </div>
          {/if}
        {/each}
      </div>

      <!-- Dark Mode Toggle -->
      <div class="flex items-center space-x-2">
        <button
          on:click={toggleDarkMode}
          class="p-2 rounded-md text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200"
          aria-label="Toggle dark mode"
        >
          {#if darkMode}
            <Sun class="h-5 w-5" />
          {:else}
            <Moon class="h-5 w-5" />
          {/if}
        </button>
      </div>
    </div>

      <!-- Mobile Navigation -->
      <div class="md:hidden border-t border-gray-200 dark:border-gray-700">
        <div class="py-2 space-y-1">
          {#each navigation as item}
            {#if item.type === 'single'}
              <a
                href={item.href}
                class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200
                  {isCurrentPage(item.href)
                    ? 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-200'
                    : 'text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700'}"
              >
                <svelte:component this={item.icon} class="h-4 w-4" />
                <span>{item.name}</span>
              </a>
            {:else if item.type === 'dropdown'}
              <div>
                <button
                  on:click={() => toggleDropdown(item.key)}
                  class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 w-full text-left
                    {isDropdownActive(item.items)
                      ? 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-200'
                      : 'text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700'}"
                >
                  <svelte:component this={item.icon} class="h-4 w-4" />
                  <span>{item.name}</span>
                  <svelte:component this={openDropdowns[item.key] ? ChevronDown : ChevronRight} class="h-3 w-3 ml-auto" />
                </button>
                
                {#if openDropdowns[item.key]}
                  <div class="ml-4 mt-1 space-y-1">
                    {#each item.items as subItem}
                      <a
                        href={subItem.href}
                        class="flex items-center space-x-3 px-3 py-2 text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors duration-200
                          {isCurrentPage(subItem.href) ? 'bg-primary-50 text-primary-700 dark:bg-primary-900 dark:text-primary-200' : ''}"
                      >
                        <svelte:component this={subItem.icon} class="h-4 w-4" />
                        <span>{subItem.name}</span>
                      </a>
                    {/each}
                  </div>
                {/if}
              </div>
            {/if}
          {/each}
        </div>
      </div>
  </div>
</nav>
