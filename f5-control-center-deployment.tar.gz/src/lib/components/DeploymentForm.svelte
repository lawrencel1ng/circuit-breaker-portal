<script lang="ts">
  import { X, Server, Database, Globe } from 'lucide-svelte';
  import type { Application } from '$lib/types';

  export let onDeploy: (application: Omit<Application, 'id'>) => void;
  export let onCancel: () => void;

  let formData = {
    name: '',
    description: '',
    deployedLanes: [] as string[],
    deploymentType: 'Virtual Servers' as 'Virtual Servers' | 'Pool Members' | 'Wide IPs'
  };

  const lanes = [
    { id: 'lane1', name: 'Lane 1' },
    { id: 'lane2', name: 'Lane 2' },
    { id: 'lane3', name: 'Lane 3' }
  ];

  const deploymentTypes = [
    { value: 'Virtual Servers', label: 'Virtual Servers', icon: Server },
    { value: 'Pool Members', label: 'Pool Members', icon: Database },
    { value: 'Wide IPs', label: 'Wide IPs', icon: Globe }
  ];

  function handleLaneToggle(laneId: string) {
    if (formData.deployedLanes.includes(laneId)) {
      formData.deployedLanes = formData.deployedLanes.filter(id => id !== laneId);
    } else {
      formData.deployedLanes = [...formData.deployedLanes, laneId];
    }
  }

  function handleSubmit() {
    if (!formData.name || !formData.description || formData.deployedLanes.length === 0) {
      return;
    }

    onDeploy({
      ...formData,
      status: 'deployed',
      createdAt: new Date().toISOString()
    });
  }
</script>

<div class="space-y-6">
  <!-- Header -->
  <div class="flex items-center justify-between">
    <h2 class="text-xl font-semibold text-gray-900 dark:text-white">Deploy New Application</h2>
    <button
      class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
      on:click={onCancel}
      aria-label="Close deployment form"
    >
      <X class="h-6 w-6" />
    </button>
  </div>

  <form on:submit|preventDefault={handleSubmit} class="space-y-6">
    <!-- Application Name -->
    <div>
      <label for="app-name" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
        Application Name
      </label>
      <input
        id="app-name"
        type="text"
        bind:value={formData.name}
        required
        class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:text-white"
        placeholder="Enter application name"
      />
    </div>

    <!-- Description -->
    <div>
      <label for="app-description" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
        Description
      </label>
      <textarea
        id="app-description"
        bind:value={formData.description}
        required
        rows="3"
        class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:text-white"
        placeholder="Enter application description"
      ></textarea>
    </div>

    <!-- Target Lanes -->
    <fieldset>
      <legend class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
        Target Lanes
      </legend>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        {#each lanes as lane (lane.id)}
          <label class="flex items-center space-x-3 p-3 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
            <input
              type="checkbox"
              checked={formData.deployedLanes.includes(lane.id)}
              on:change={() => handleLaneToggle(lane.id)}
              class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 dark:border-gray-600 rounded"
            />
            <span class="text-sm font-medium text-gray-700 dark:text-gray-300">{lane.name}</span>
          </label>
        {/each}
      </div>
    </fieldset>

    <!-- Deployment Type -->
    <fieldset>
      <legend class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
        Deployment Type
      </legend>
      <div class="space-y-3">
        {#each deploymentTypes as type (type.value)}
          <label class="flex items-center space-x-3 p-3 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700
            {formData.deploymentType === type.value ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20' : ''}">
            <input
              type="radio"
              bind:group={formData.deploymentType}
              value={type.value}
              class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 dark:border-gray-600"
            />
            <svelte:component this={type.icon} class="h-5 w-5 text-gray-500" />
            <span class="text-sm font-medium text-gray-700 dark:text-gray-300">{type.label}</span>
          </label>
        {/each}
      </div>
    </fieldset>

    <!-- Actions -->
    <div class="flex justify-end space-x-3 pt-4 border-t border-gray-200 dark:border-gray-700">
      <button
        type="button"
        class="btn-secondary"
        on:click={onCancel}
      >
        Cancel
      </button>
      <button
        type="submit"
        class="btn-primary"
        disabled={!formData.name || !formData.description || formData.deployedLanes.length === 0}
      >
        Deploy Application
      </button>
    </div>
  </form>
</div>
