<script lang="ts">
  import { ArrowRight, Server, Globe, Database } from 'lucide-svelte';
  import type { Lane } from '$lib/types';

  export let lanes: Lane[];

  function getLaneColor(lane: Lane) {
    if (lane.edgeStatus === 'closed' || lane.enterpriseStatus === 'closed') {
      return 'bg-gray-400 dark:bg-gray-600';
    }
    switch (lane.healthStatus) {
      case 'healthy':
        return 'bg-success-500';
      case 'degraded':
        return 'bg-warning-500';
      case 'down':
        return 'bg-danger-500';
      default:
        return 'bg-gray-400';
    }
  }

  function getLaneBorderColor(lane: Lane) {
    if (lane.edgeStatus === 'closed' || lane.enterpriseStatus === 'closed') {
      return 'border-gray-400 dark:border-gray-600';
    }
    switch (lane.healthStatus) {
      case 'healthy':
        return 'border-success-500';
      case 'degraded':
        return 'border-warning-500';
      case 'down':
        return 'border-danger-500';
      default:
        return 'border-gray-400';
    }
  }

  function getLaneOpacity(lane: Lane) {
    if (lane.edgeStatus === 'closed' || lane.enterpriseStatus === 'closed') {
      return 'opacity-50';
    }
    return 'opacity-100';
  }
</script>

<div class="relative">
  <!-- Clients -->
  <div class="flex justify-center mb-8">
    <div class="flex items-center space-x-4 bg-gray-100 dark:bg-gray-700 rounded-lg p-4">
      <Globe class="h-6 w-6 text-gray-600 dark:text-gray-300" />
      <span class="font-medium text-gray-900 dark:text-white">Clients</span>
    </div>
  </div>

  <!-- Arrow to Edge -->
  <div class="flex justify-center mb-4">
    <ArrowRight class="h-6 w-6 text-gray-400 transform rotate-90" />
  </div>

  <!-- Edge Circuit Breaker -->
  <div class="flex justify-center mb-8">
    <div class="bg-primary-100 dark:bg-primary-900 border-2 border-primary-300 dark:border-primary-700 rounded-lg p-4">
      <div class="flex items-center space-x-2">
        <Server class="h-5 w-5 text-primary-600" />
        <span class="font-medium text-primary-900 dark:text-primary-100">Edge Circuit Breaker (GSLB)</span>
      </div>
    </div>
  </div>

  <!-- Arrow to Lanes -->
  <div class="flex justify-center mb-4">
    <ArrowRight class="h-6 w-6 text-gray-400 transform rotate-90" />
  </div>

  <!-- Lanes -->
  <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
    {#each lanes as lane, index (lane.id)}
      <div class="text-center">
        <!-- Edge Lane -->
        <div class="mb-4">
          <div class="bg-white dark:bg-gray-800 border-2 {getLaneBorderColor(lane)} rounded-lg p-4 {getLaneOpacity(lane)} transition-all duration-300">
            <div class="flex items-center justify-center space-x-2 mb-2">
              <div class="w-3 h-3 rounded-full {getLaneColor(lane)} animate-pulse"></div>
              <span class="font-medium text-gray-900 dark:text-white">Edge {lane.name}</span>
            </div>
            <div class="text-sm text-gray-600 dark:text-gray-400">
              {lane.trafficDistribution.toFixed(1)}% traffic
            </div>
            <div class="text-xs text-gray-500 dark:text-gray-500 mt-1">
              Status: {lane.edgeStatus}
            </div>
          </div>
        </div>

        <!-- Arrow to Enterprise -->
        <div class="flex justify-center mb-4">
          <ArrowRight class="h-4 w-4 text-gray-400 transform rotate-90" />
        </div>

        <!-- Enterprise Lane -->
        <div class="bg-white dark:bg-gray-800 border-2 {getLaneBorderColor(lane)} rounded-lg p-4 {getLaneOpacity(lane)} transition-all duration-300">
          <div class="flex items-center justify-center space-x-2 mb-2">
            <div class="w-3 h-3 rounded-full {getLaneColor(lane)} animate-pulse"></div>
            <span class="font-medium text-gray-900 dark:text-white">Enterprise {lane.name}</span>
          </div>
          <div class="text-sm text-gray-600 dark:text-gray-400">
            {lane.deployments.length} deployments
          </div>
          <div class="text-xs text-gray-500 dark:text-gray-500 mt-1">
            Status: {lane.enterpriseStatus}
          </div>
        </div>
      </div>
    {/each}
  </div>

  <!-- Arrow to Enterprise Circuit Breaker -->
  <div class="flex justify-center mb-4">
    <ArrowRight class="h-6 w-6 text-gray-400 transform rotate-90" />
  </div>

  <!-- Enterprise Circuit Breaker -->
  <div class="flex justify-center">
    <div class="bg-primary-100 dark:bg-primary-900 border-2 border-primary-300 dark:border-primary-700 rounded-lg p-4">
      <div class="flex items-center space-x-2">
        <Database class="h-5 w-5 text-primary-600" />
        <span class="font-medium text-primary-900 dark:text-primary-100">Enterprise Circuit Breaker (GSLB)</span>
      </div>
    </div>
  </div>

  <!-- Legend -->
  <div class="mt-8 flex justify-center">
    <div class="bg-gray-100 dark:bg-gray-700 rounded-lg p-4">
      <div class="flex items-center space-x-6 text-sm">
        <div class="flex items-center space-x-2">
          <div class="w-3 h-3 rounded-full bg-success-500"></div>
          <span class="text-gray-700 dark:text-gray-300">Healthy</span>
        </div>
        <div class="flex items-center space-x-2">
          <div class="w-3 h-3 rounded-full bg-warning-500"></div>
          <span class="text-gray-700 dark:text-gray-300">Degraded</span>
        </div>
        <div class="flex items-center space-x-2">
          <div class="w-3 h-3 rounded-full bg-danger-500"></div>
          <span class="text-gray-700 dark:text-gray-300">Down</span>
        </div>
        <div class="flex items-center space-x-2">
          <div class="w-3 h-3 rounded-full bg-gray-400"></div>
          <span class="text-gray-700 dark:text-gray-300">Closed</span>
        </div>
      </div>
    </div>
  </div>
</div>
