import { writable } from 'svelte/store';
import type { CircuitBreakerConfig, Lane, Application, AutomationLog } from '../types';

// Initial state with realistic demo data
const initialState: CircuitBreakerConfig = {
  lanes: [
    {
      id: 'lane1',
      name: 'Lane 1 - Primary',
      edgeStatus: 'active',
      enterpriseStatus: 'active',
      healthStatus: 'healthy',
      trafficDistribution: 40,
      edgeLoadBalancer: {
        virtualServers: [
          { id: 'vs1', name: 'Edge-VS-1', ip: '10.1.1.10', port: 80, status: 'enabled' },
          { id: 'vs2', name: 'Edge-VS-2', ip: '10.1.1.11', port: 443, status: 'enabled' }
        ],
        pools: [
          { id: 'pool1', name: 'Edge-Pool-1', members: 3, status: 'enabled' }
        ],
        poolMembers: [
          { id: 'pm1', name: 'Edge-Server-1', ip: '10.1.1.20', port: 8080, status: 'enabled', health: 'up' },
          { id: 'pm2', name: 'Edge-Server-2', ip: '10.1.1.21', port: 8080, status: 'enabled', health: 'up' },
          { id: 'pm3', name: 'Edge-Server-3', ip: '10.1.1.22', port: 8080, status: 'enabled', health: 'up' }
        ]
      },
      enterpriseLoadBalancer: {
        virtualServers: [
          { id: 'evs1', name: 'Ent-VS-1', ip: '10.2.1.10', port: 80, status: 'enabled' }
        ],
        pools: [
          { id: 'epool1', name: 'Ent-Pool-1', members: 4, status: 'enabled' }
        ],
        poolMembers: [
          { id: 'epm1', name: 'App-Server-1', ip: '10.2.1.20', port: 8080, status: 'enabled', health: 'up' },
          { id: 'epm2', name: 'App-Server-2', ip: '10.2.1.21', port: 8080, status: 'enabled', health: 'up' },
          { id: 'epm3', name: 'App-Server-3', ip: '10.2.1.22', port: 8080, status: 'enabled', health: 'up' },
          { id: 'epm4', name: 'App-Server-4', ip: '10.2.1.23', port: 8080, status: 'enabled', health: 'up' }
        ]
      },
      edgeCircuitBreaker: {
        wideIPs: [
          { id: 'wip1', name: 'api.ocbc.com', ip: '203.0.113.10', status: 'enabled' }
        ],
        pools: [
          { id: 'gslb1', name: 'GSLB-Pool-1', members: 3, status: 'enabled' }
        ]
      },
      enterpriseCircuitBreaker: {
        wideIPs: [
          { id: 'ewip1', name: 'internal-api.ocbc.com', ip: '10.2.1.100', status: 'enabled' }
        ],
        pools: [
          { id: 'egslb1', name: 'Ent-GSLB-Pool-1', members: 4, status: 'enabled' }
        ]
      },
      deployments: [
        { id: 'dep1', name: 'OCBC Mobile Banking API', servers: ['App-Server-1', 'App-Server-2'], status: 'running' },
        { id: 'dep2', name: 'OCBC Payment Gateway', servers: ['App-Server-3', 'App-Server-4'], status: 'running' }
      ]
    },
    {
      id: 'lane2',
      name: 'Lane 2 - Secondary',
      edgeStatus: 'active',
      enterpriseStatus: 'active',
      healthStatus: 'healthy',
      trafficDistribution: 35,
      edgeLoadBalancer: {
        virtualServers: [
          { id: 'vs3', name: 'Edge-VS-3', ip: '10.1.2.10', port: 80, status: 'enabled' },
          { id: 'vs4', name: 'Edge-VS-4', ip: '10.1.2.11', port: 443, status: 'enabled' }
        ],
        pools: [
          { id: 'pool2', name: 'Edge-Pool-2', members: 3, status: 'enabled' }
        ],
        poolMembers: [
          { id: 'pm4', name: 'Edge-Server-4', ip: '10.1.2.20', port: 8080, status: 'enabled', health: 'up' },
          { id: 'pm5', name: 'Edge-Server-5', ip: '10.1.2.21', port: 8080, status: 'enabled', health: 'up' },
          { id: 'pm6', name: 'Edge-Server-6', ip: '10.1.2.22', port: 8080, status: 'enabled', health: 'up' }
        ]
      },
      enterpriseLoadBalancer: {
        virtualServers: [
          { id: 'evs2', name: 'Ent-VS-2', ip: '10.2.2.10', port: 80, status: 'enabled' }
        ],
        pools: [
          { id: 'epool2', name: 'Ent-Pool-2', members: 4, status: 'enabled' }
        ],
        poolMembers: [
          { id: 'epm5', name: 'App-Server-5', ip: '10.2.2.20', port: 8080, status: 'enabled', health: 'up' },
          { id: 'epm6', name: 'App-Server-6', ip: '10.2.2.21', port: 8080, status: 'enabled', health: 'up' },
          { id: 'epm7', name: 'App-Server-7', ip: '10.2.2.22', port: 8080, status: 'enabled', health: 'up' },
          { id: 'epm8', name: 'App-Server-8', ip: '10.2.2.23', port: 8080, status: 'enabled', health: 'up' }
        ]
      },
      edgeCircuitBreaker: {
        wideIPs: [
          { id: 'wip2', name: 'api.ocbc.com', ip: '203.0.113.11', status: 'enabled' }
        ],
        pools: [
          { id: 'gslb2', name: 'GSLB-Pool-2', members: 3, status: 'enabled' }
        ]
      },
      enterpriseCircuitBreaker: {
        wideIPs: [
          { id: 'ewip2', name: 'internal-api.ocbc.com', ip: '10.2.2.100', status: 'enabled' }
        ],
        pools: [
          { id: 'egslb2', name: 'Ent-GSLB-Pool-2', members: 4, status: 'enabled' }
        ]
      },
      deployments: [
        { id: 'dep3', name: 'OCBC Internet Banking', servers: ['App-Server-5', 'App-Server-6'], status: 'running' },
        { id: 'dep4', name: 'OCBC Credit Card API', servers: ['App-Server-7', 'App-Server-8'], status: 'running' }
      ]
    },
    {
      id: 'lane3',
      name: 'Lane 3 - DR Site',
      edgeStatus: 'inactive',
      enterpriseStatus: 'inactive',
      healthStatus: 'healthy',
      trafficDistribution: 25,
      edgeLoadBalancer: {
        virtualServers: [
          { id: 'vs5', name: 'Edge-VS-5', ip: '10.1.3.10', port: 80, status: 'disabled' },
          { id: 'vs6', name: 'Edge-VS-6', ip: '10.1.3.11', port: 443, status: 'disabled' }
        ],
        pools: [
          { id: 'pool3', name: 'Edge-Pool-3', members: 3, status: 'disabled' }
        ],
        poolMembers: [
          { id: 'pm7', name: 'Edge-Server-7', ip: '10.1.3.20', port: 8080, status: 'disabled', health: 'up' },
          { id: 'pm8', name: 'Edge-Server-8', ip: '10.1.3.21', port: 8080, status: 'disabled', health: 'up' },
          { id: 'pm9', name: 'Edge-Server-9', ip: '10.1.3.22', port: 8080, status: 'disabled', health: 'up' }
        ]
      },
      enterpriseLoadBalancer: {
        virtualServers: [
          { id: 'evs3', name: 'Ent-VS-3', ip: '10.2.3.10', port: 80, status: 'disabled' }
        ],
        pools: [
          { id: 'epool3', name: 'Ent-Pool-3', members: 4, status: 'disabled' }
        ],
        poolMembers: [
          { id: 'epm9', name: 'App-Server-9', ip: '10.2.3.20', port: 8080, status: 'disabled', health: 'up' },
          { id: 'epm10', name: 'App-Server-10', ip: '10.2.3.21', port: 8080, status: 'disabled', health: 'up' },
          { id: 'epm11', name: 'App-Server-11', ip: '10.2.3.22', port: 8080, status: 'disabled', health: 'up' },
          { id: 'epm12', name: 'App-Server-12', ip: '10.2.3.23', port: 8080, status: 'disabled', health: 'up' }
        ]
      },
      edgeCircuitBreaker: {
        wideIPs: [
          { id: 'wip3', name: 'api.ocbc.com', ip: '203.0.113.12', status: 'disabled' }
        ],
        pools: [
          { id: 'gslb3', name: 'GSLB-Pool-3', members: 3, status: 'disabled' }
        ]
      },
      enterpriseCircuitBreaker: {
        wideIPs: [
          { id: 'ewip3', name: 'internal-api.ocbc.com', ip: '10.2.3.100', status: 'disabled' }
        ],
        pools: [
          { id: 'egslb3', name: 'Ent-GSLB-Pool-3', members: 4, status: 'disabled' }
        ]
      },
      deployments: [
        { id: 'dep5', name: 'OCBC ATM Network', servers: ['App-Server-9', 'App-Server-10'], status: 'standby' },
        { id: 'dep6', name: 'OCBC Core Banking', servers: ['App-Server-11', 'App-Server-12'], status: 'standby' }
      ]
    }
  ],
  applications: [
    {
      id: 'app1',
      name: 'OCBC Mobile Banking',
      description: 'Mobile banking application for iOS and Android',
      version: '2.4.1',
      status: 'running',
      deployedLanes: ['lane1', 'lane2'],
      lastDeployed: '2024-01-15T10:30:00Z',
      health: 'healthy'
    },
    {
      id: 'app2',
      name: 'OCBC Internet Banking',
      description: 'Web-based banking platform',
      version: '1.8.3',
      status: 'running',
      deployedLanes: ['lane1', 'lane2'],
      lastDeployed: '2024-01-14T15:45:00Z',
      health: 'healthy'
    },
    {
      id: 'app3',
      name: 'OCBC Payment Gateway',
      description: 'Payment processing and gateway services',
      version: '3.1.0',
      status: 'running',
      deployedLanes: ['lane1', 'lane2'],
      lastDeployed: '2024-01-13T09:20:00Z',
      health: 'healthy'
    }
  ],
  automationLogs: [
    {
      id: 'log1',
      timestamp: '2024-01-15T14:30:00Z',
      lane: 'lane1',
      action: 'health_check_passed',
      user: 'system',
      details: 'All health checks passed for Lane 1',
      status: 'success'
    },
    {
      id: 'log2',
      timestamp: '2024-01-15T14:25:00Z',
      lane: 'lane2',
      action: 'application_deployed',
      user: 'admin',
      details: 'OCBC Mobile Banking v2.4.1 deployed to Lane 2',
      status: 'success'
    },
    {
      id: 'log3',
      timestamp: '2024-01-15T14:20:00Z',
      lane: 'lane1',
      action: 'configuration_changed',
      user: 'admin',
      details: 'Updated load balancer pool configuration',
      status: 'success'
    },
    {
      id: 'log4',
      timestamp: '2024-01-15T14:15:00Z',
      lane: 'lane3',
      action: 'lane_activated',
      user: 'admin',
      details: 'Lane 3 activated for maintenance testing',
      status: 'success'
    },
    {
      id: 'log5',
      timestamp: '2024-01-15T14:10:00Z',
      lane: 'lane2',
      action: 'health_check_failed',
      user: 'system',
      details: 'Health check failed for App-Server-6, triggering failover',
      status: 'warning'
    }
  ],
  globalSettings: {
    healthCheckInterval: 10,
    circuitBreakerThreshold: 3,
    autoFailoverEnabled: true,
    maintenanceMode: false
  }
};

// Create the store
export const circuitBreakerStore = writable<CircuitBreakerConfig>(initialState);

// Store methods
export const circuitBreakerActions = {
  loadConfig: async () => {
    try {
      const response = await fetch('/circuitBreakerConfig.json');
      const config = await response.json();
      circuitBreakerStore.set(config);
    } catch (error) {
      console.error('Failed to load configuration:', error);
    }
  },

  saveConfig: async (config: CircuitBreakerConfig) => {
    try {
      // In a real application, this would be an API call
      // For demo purposes, we'll just update the store
      circuitBreakerStore.set(config);
      console.log('Configuration saved');
    } catch (error) {
      console.error('Failed to save configuration:', error);
    }
  },

  updateLaneStatus: (laneId: string, edgeStatus: string, enterpriseStatus: string) => {
    circuitBreakerStore.update(config => {
      const updatedLanes = config.lanes.map(lane => 
        lane.id === laneId 
          ? { ...lane, edgeStatus, enterpriseStatus }
          : lane
      );
      return { ...config, lanes: updatedLanes };
    });
  },

  flipDownLane: (laneId: string) => {
    circuitBreakerStore.update(config => {
      const updatedLanes = config.lanes.map(lane => 
        lane.id === laneId 
          ? { 
              ...lane, 
              edgeStatus: 'closed', 
              enterpriseStatus: 'closed',
              healthStatus: 'down'
            }
          : lane
      );
      
      // Add log entry
      const logEntry: AutomationLog = {
        id: `log_${Date.now()}`,
        timestamp: new Date().toISOString(),
        lane: laneId,
        action: 'lane_flipped_down',
        user: 'admin',
        details: `Lane ${laneId} flipped down manually`,
        status: 'success'
      };
      
      return {
        ...config,
        lanes: updatedLanes,
        automationLogs: [logEntry, ...config.automationLogs]
      };
    });
  },

  addApplication: (application: Omit<Application, 'id'>) => {
    circuitBreakerStore.update(config => {
      const newApp: Application = {
        ...application,
        id: `app_${Date.now()}`
      };
      
      const logEntry: AutomationLog = {
        id: `log_${Date.now()}`,
        timestamp: new Date().toISOString(),
        lane: 'all',
        action: 'application_deployed',
        user: 'admin',
        details: `Application ${application.name} deployed`,
        status: 'success'
      };
      
      return {
        ...config,
        applications: [...config.applications, newApp],
        automationLogs: [logEntry, ...config.automationLogs]
      };
    });
  },

  addLogEntry: (logEntry: Omit<AutomationLog, 'id'>) => {
    circuitBreakerStore.update(config => {
      const newLog: AutomationLog = {
        ...logEntry,
        id: `log_${Date.now()}`
      };
      
      return {
        ...config,
        automationLogs: [newLog, ...config.automationLogs]
      };
    });
  }
};
