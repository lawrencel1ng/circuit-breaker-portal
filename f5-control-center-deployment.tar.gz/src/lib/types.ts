export interface CircuitBreakerConfig {
  lanes: Lane[];
  applications: Application[];
  automationLogs: AutomationLog[];
  globalSettings: GlobalSettings;
}

export interface Lane {
  id: string;
  name: string;
  edgeStatus: 'active' | 'inactive' | 'closed';
  enterpriseStatus: 'active' | 'inactive' | 'closed';
  edgeLoadBalancer: LoadBalancerConfig;
  enterpriseLoadBalancer: LoadBalancerConfig;
  edgeCircuitBreaker: CircuitBreakerConfig;
  enterpriseCircuitBreaker: CircuitBreakerConfig;
  deployments: Deployment[];
  trafficDistribution: number;
  healthStatus: 'healthy' | 'degraded' | 'down';
}

export interface LoadBalancerConfig {
  virtualServers: VirtualServer[];
  pools: Pool[];
}

export interface VirtualServer {
  name: string;
  ip: string;
  port: number;
  status: 'enabled' | 'disabled';
}

export interface Pool {
  name: string;
  members: PoolMember[];
}

export interface PoolMember {
  name: string;
  ip: string;
  port: number;
  status: 'enabled' | 'disabled';
}

export interface CircuitBreakerConfig {
  wideIPs: WideIP[];
  pools: Pool[];
}

export interface WideIP {
  name: string;
  domain: string;
  status: 'active' | 'inactive';
}

export interface Deployment {
  id: string;
  name: string;
  servers: Server[];
  status: 'running' | 'stopped' | 'deploying';
}

export interface Server {
  name: string;
  ip: string;
  status: 'running' | 'stopped';
  health: 'healthy' | 'unhealthy';
}

export interface Application {
  id: string;
  name: string;
  description: string;
  deployedLanes: string[];
  deploymentType: 'Virtual Servers' | 'Pool Members' | 'Wide IPs';
  status: 'deployed' | 'deploying' | 'failed';
  createdAt: string;
}

export interface AutomationLog {
  id: string;
  timestamp: string;
  lane: string;
  action: string;
  user: string;
  details: string;
  status: 'success' | 'error' | 'warning';
}

export interface GlobalSettings {
  healthCheckInterval: number;
  circuitBreakerThreshold: number;
  autoFailoverEnabled: boolean;
  maintenanceMode: boolean;
}

// Deployment Portal Types
export interface DeploymentRequest {
  id: string;
  timestamp: string;
  developer: string;
  applicationName: string;
  applicationType: 'web' | 'api' | 'tcp' | 'udp';
  securityLevel: 'low' | 'medium' | 'high' | 'critical';
  environment: 'development' | 'staging' | 'production';
  description: string;
  status: 'pending' | 'approved' | 'deploying' | 'deployed' | 'failed';
  vipAddress: string | null;
  monitoringUrl: string | null;
  as3Declaration: AS3Declaration | null;
}

export interface DeployedService {
  id: string;
  name: string;
  vipAddress: string;
  port: number;
  protocol: 'HTTP' | 'HTTPS' | 'TCP' | 'UDP';
  status: 'active' | 'inactive' | 'maintenance';
  health: 'healthy' | 'degraded' | 'unhealthy';
  traffic: number;
  responseTime: number;
  errorRate: number;
  deployedAt: string;
  lastUpdated: string;
  poolMembers: PoolMemberHealth[];
  sslProfile: string;
  wafPolicy: string;
  monitoringUrl: string;
}

export interface PoolMemberHealth {
  name: string;
  ip: string;
  port: number;
  status: 'up' | 'down' | 'disabled';
  health: 'healthy' | 'degraded' | 'unhealthy';
}

export interface AS3Declaration {
  id: string;
  requestId: string;
  declaration: {
    class: string;
    schemaVersion: string;
    target: {
      host: string;
      username: string;
      passphrase: string;
    };
    declaration: any;
  };
}
