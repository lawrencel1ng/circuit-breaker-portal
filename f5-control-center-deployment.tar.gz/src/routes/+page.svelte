<script lang="ts">
  import { onMount } from 'svelte';
  import { circuitBreakerStore } from '$lib/stores/circuitBreakerStore';
  import { notificationStore } from '$lib/components/NotificationStore.svelte.ts';
  import LaneCard from '$lib/components/LaneCard.svelte';
  import TrafficFlowDiagram from '$lib/components/TrafficFlowDiagram.svelte';
  import QuickStats from '$lib/components/QuickStats.svelte';
  import RecentLogs from '$lib/components/RecentLogs.svelte';
  import DemoScenarios from '$lib/components/DemoScenarios.svelte';
  import type { CircuitBreakerConfig, Lane } from '$lib/types';

  let config: CircuitBreakerConfig;
  let lanes: Lane[] = [];

  circuitBreakerStore.subscribe(value => {
    config = value;
    lanes = value.lanes;
  });

  onMount(() => {
    // Simulate real-time updates (disabled during demo scenarios)
    const interval = setInterval(() => {
      // Only simulate health changes if no demo scenario is running
      if (!document.querySelector('[data-demo-running="true"]')) {
        circuitBreakerStore.update(currentConfig => {
          const updatedLanes = currentConfig.lanes.map(lane => {
            // Simulate occasional health changes
            if (Math.random() < 0.05) { // Reduced frequency
              const healthStatuses = ['healthy', 'degraded', 'down'] as const;
              const randomHealth = healthStatuses[Math.floor(Math.random() * healthStatuses.length)];
              return { ...lane, healthStatus: randomHealth };
            }
            return lane;
          });
          return { ...currentConfig, lanes: updatedLanes };
        });
      }
    }, 15000); // Update every 15 seconds

    return () => clearInterval(interval);
  });

  function getOverallStatus() {
    const activeLanes = lanes.filter(lane => lane.edgeStatus === 'active' && lane.enterpriseStatus === 'active');
    const healthyLanes = activeLanes.filter(lane => lane.healthStatus === 'healthy');
    
    if (healthyLanes.length === activeLanes.length && activeLanes.length > 0) {
      return 'healthy';
    } else if (healthyLanes.length > 0) {
      return 'degraded';
    } else {
      return 'down';
    }
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'healthy': return 'text-green-600 dark:text-green-400';
      case 'degraded': return 'text-yellow-600 dark:text-yellow-400';
      case 'down': return 'text-red-600 dark:text-red-400';
      default: return 'text-gray-600 dark:text-gray-400';
    }
  }

  function getStatusIcon(status: string) {
    switch (status) {
      case 'healthy': return '🟢';
      case 'degraded': return '🟡';
      case 'down': return '🔴';
      default: return '⚪';
    }
  }


  function getStatusText(status: string) {
    switch (status) {
      case 'healthy':
        return 'All Systems Operational';
      case 'degraded':
        return 'Some Issues Detected';
      case 'down':
        return 'System Down';
      default:
        return 'Unknown Status';
    }
  }
</script>

<svelte:head>
  <title>Circuit Breaker Dashboard - OCBC Portal</title>
</svelte:head>

<div class="space-y-8">
  <!-- Header with OCBC Branding -->
  <div class="text-center bg-gradient-to-r from-blue-600 to-blue-800 dark:from-blue-800 dark:to-blue-900 rounded-xl p-8 text-white">
    <div class="flex items-center justify-center mb-4">
      <div class="w-16 h-16 bg-white rounded-full flex items-center justify-center mr-4">
        <span class="text-2xl font-bold text-blue-600">OCBC</span>
      </div>
      <div>
        <h1 class="text-4xl font-bold mb-2">
          Circuit Breaker Management Portal
        </h1>
        <p class="text-xl text-blue-100">
          Multi-Lane Traffic Management System
        </p>
      </div>
    </div>
    
          <!-- System Status Badge -->
          <div class="inline-flex items-center px-6 py-3 bg-white/20 backdrop-blur-sm rounded-full">
            <span class="text-2xl mr-3">{getStatusIcon(getOverallStatus())}</span>
            <span class="text-lg font-semibold">{getStatusText(getOverallStatus())}</span>
          </div>
          
          <!-- Demo Status Indicator -->
          <div class="mt-4 text-sm text-blue-100">
            <span class="inline-flex items-center px-3 py-1 bg-white/10 rounded-full">
              <span class="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></span>
              Demo Mode Active
            </span>
          </div>
    
    <p class="text-sm text-blue-100 mt-4">
      Last updated: {new Date().toLocaleTimeString()}
    </p>
  </div>

  <!-- Integration Status Overview -->
  <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
    <h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-4">F5 Integration Roadmap</h2>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <!-- Phase 1: Ready to Integrate -->
      <div class="space-y-3">
        <div class="flex items-center space-x-2 mb-3">
          <div class="w-3 h-3 bg-green-500 rounded-full"></div>
          <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Phase 1: Ready to Integrate</h3>
        </div>
        <div class="space-y-2 text-sm">
          <div class="flex items-center space-x-2">
            <div class="w-2 h-2 bg-green-500 rounded-full"></div>
            <span class="text-gray-700 dark:text-gray-300">Self-Service Deployments (AS3 API)</span>
          </div>
          <div class="flex items-center space-x-2">
            <div class="w-2 h-2 bg-green-500 rounded-full"></div>
            <span class="text-gray-700 dark:text-gray-300">Circuit Breakers (iControl REST)</span>
          </div>
          <div class="flex items-center space-x-2">
            <div class="w-2 h-2 bg-green-500 rounded-full"></div>
            <span class="text-gray-700 dark:text-gray-300">Certificate Management (SSL Orchestrator)</span>
          </div>
          <div class="flex items-center space-x-2">
            <div class="w-2 h-2 bg-green-500 rounded-full"></div>
            <span class="text-gray-700 dark:text-gray-300">Security Automation (AWAF)</span>
          </div>
        </div>
        <div class="text-xs text-gray-500 dark:text-gray-400 mt-2">
          <strong>Requirements:</strong> F5 BIG-IP with iControl REST, AS3 Extension
        </div>
      </div>

      <!-- Phase 2: Additional Work Required -->
      <div class="space-y-3">
        <div class="flex items-center space-x-2 mb-3">
          <div class="w-3 h-3 bg-yellow-500 rounded-full"></div>
          <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Phase 2: Additional Work</h3>
        </div>
        <div class="space-y-2 text-sm">
          <div class="flex items-center space-x-2">
            <div class="w-2 h-2 bg-yellow-500 rounded-full"></div>
            <span class="text-gray-700 dark:text-gray-300">Blue/Green Deployments</span>
          </div>
          <div class="flex items-center space-x-2">
            <div class="w-2 h-2 bg-yellow-500 rounded-full"></div>
            <span class="text-gray-700 dark:text-gray-300">Multi-Cloud Routing</span>
          </div>
        </div>
        <div class="text-xs text-gray-500 dark:text-gray-400 mt-2">
          <strong>Requirements:</strong> F5 GTM, custom iRules, cloud provider APIs
        </div>
      </div>

      <!-- Phase 3: Future Roadmap -->
      <div class="space-y-3">
        <div class="flex items-center space-x-2 mb-3">
          <div class="w-3 h-3 bg-blue-500 rounded-full"></div>
          <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Phase 3: Future Roadmap</h3>
        </div>
        <div class="space-y-2 text-sm">
          <div class="flex items-center space-x-2">
            <div class="w-2 h-2 bg-blue-500 rounded-full"></div>
            <span class="text-gray-700 dark:text-gray-300">Cloud Auto-Scaling</span>
          </div>
          <div class="flex items-center space-x-2">
            <div class="w-2 h-2 bg-blue-500 rounded-full"></div>
            <span class="text-gray-700 dark:text-gray-300">Advanced Analytics</span>
          </div>
        </div>
        <div class="text-xs text-gray-500 dark:text-gray-400 mt-2">
          <strong>Requirements:</strong> F5 Cloud Edition, external monitoring tools, Kubernetes integration
        </div>
      </div>
    </div>
  </div>

  <!-- Key Metrics Dashboard -->
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
    <div class="card p-6 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 border-green-200 dark:border-green-700">
      <div class="flex items-center justify-between">
        <div>
          <p class="text-sm font-medium text-green-600 dark:text-green-400">Active Lanes</p>
          <p class="text-3xl font-bold text-green-700 dark:text-green-300">
            {lanes.filter(l => l.edgeStatus === 'active' && l.enterpriseStatus === 'active').length}
          </p>
        </div>
        <div class="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
          <span class="text-white text-xl">🚦</span>
        </div>
      </div>
    </div>

    <div class="card p-6 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 border-blue-200 dark:border-blue-700">
      <div class="flex items-center justify-between">
        <div>
          <p class="text-sm font-medium text-blue-600 dark:text-blue-400">Total Applications</p>
          <p class="text-3xl font-bold text-blue-700 dark:text-blue-300">
            {config?.applications?.length || 0}
          </p>
        </div>
        <div class="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
          <span class="text-white text-xl">📱</span>
        </div>
      </div>
    </div>

    <div class="card p-6 bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 border-purple-200 dark:border-purple-700">
      <div class="flex items-center justify-between">
        <div>
          <p class="text-sm font-medium text-purple-600 dark:text-purple-400">Total Servers</p>
          <p class="text-3xl font-bold text-purple-700 dark:text-purple-300">
            {lanes.reduce((total, lane) => total + (lane.edgeLoadBalancer?.poolMembers?.length || 0) + (lane.enterpriseLoadBalancer?.poolMembers?.length || 0), 0)}
          </p>
        </div>
        <div class="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center">
          <span class="text-white text-xl">🖥️</span>
        </div>
      </div>
    </div>

    <div class="card p-6 bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 border-orange-200 dark:border-orange-700">
      <div class="flex items-center justify-between">
        <div>
          <p class="text-sm font-medium text-orange-600 dark:text-orange-400">Uptime</p>
          <p class="text-3xl font-bold text-orange-700 dark:text-orange-300">99.9%</p>
        </div>
        <div class="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center">
          <span class="text-white text-xl">⏱️</span>
        </div>
      </div>
    </div>
  </div>

  <!-- Quick Stats -->
  <QuickStats {config} />

  <!-- Traffic Flow Diagram -->
  <div class="card p-6">
    <h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-4">Traffic Flow Overview</h2>
    <TrafficFlowDiagram {lanes} />
  </div>

  <!-- Demo Scenarios -->
  <DemoScenarios />

  <!-- Lane Overview -->
  <div class="card p-6">
    <div class="flex items-center justify-between mb-6">
      <h2 class="text-xl font-semibold text-gray-900 dark:text-white">Lane Status Overview</h2>
      <div class="text-sm text-gray-500 dark:text-gray-400">
        Last updated: {new Date().toLocaleTimeString()}
      </div>
    </div>
    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {#each lanes as lane (lane.id)}
        <LaneCard {lane} />
      {/each}
    </div>
  </div>

  <!-- Recent Activity -->
  <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
    <RecentLogs {config} />
    
    <!-- Quick Actions -->
    <div class="card p-6">
      <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Quick Actions</h3>
      <div class="space-y-3">
        <button
          class="w-full btn-primary text-left"
          on:click={() => {
            notificationStore.add({
              type: 'info',
              title: 'Feature Coming Soon',
              message: 'Quick actions will be available in the Control Panel'
            });
          }}
        >
          Activate All Lanes
        </button>
        <button
          class="w-full btn-secondary text-left"
          on:click={() => {
            notificationStore.add({
              type: 'info',
              title: 'Feature Coming Soon',
              message: 'Failover actions will be available in the Control Panel'
            });
          }}
        >
          Failover to Lane 2
        </button>
        <button
          class="w-full btn-secondary text-left"
          on:click={() => {
            notificationStore.add({
              type: 'info',
              title: 'Feature Coming Soon',
              message: 'Maintenance mode will be available in the Control Panel'
            });
          }}
        >
          Enter Maintenance Mode
        </button>
      </div>
    </div>
  </div>
</div>
