<script lang="ts">
  import { onMount } from 'svelte';
  import { Shield, AlertTriangle, CheckCircle, XCircle, Eye, Lock, Zap, Activity } from 'lucide-svelte';

  let securityMetrics = {
    totalThreats: 1247,
    blockedThreats: 1189,
    falsePositives: 23,
    avgResponseTime: 45
  };

  let threatTypes = [
    { type: 'SQL Injection', count: 456, blocked: 445, trend: 'down' },
    { type: 'XSS Attacks', count: 234, blocked: 228, trend: 'down' },
    { type: 'DDoS', count: 189, blocked: 189, trend: 'stable' },
    { type: 'Bot Traffic', count: 198, blocked: 156, trend: 'up' },
    { type: 'Malware', count: 89, blocked: 89, trend: 'down' },
    { type: 'Brute Force', count: 81, blocked: 81, trend: 'stable' }
  ];

  let wafRules = [
    { id: 'rule1', name: 'SQL Injection Protection', status: 'active', severity: 'high', lastUpdated: '2 hours ago', blocks: 445 },
    { id: 'rule2', name: 'XSS Protection', status: 'active', severity: 'high', lastUpdated: '1 hour ago', blocks: 228 },
    { id: 'rule3', name: 'DDoS Mitigation', status: 'active', severity: 'critical', lastUpdated: '30 min ago', blocks: 189 },
    { id: 'rule4', name: 'Bot Detection', status: 'active', severity: 'medium', lastUpdated: '3 hours ago', blocks: 156 },
    { id: 'rule5', name: 'Rate Limiting', status: 'active', severity: 'medium', lastUpdated: '1 hour ago', blocks: 89 },
    { id: 'rule6', name: 'Geo-blocking', status: 'active', severity: 'low', lastUpdated: '4 hours ago', blocks: 45 }
  ];

  let recentIncidents = [
    { id: 'inc1', timestamp: '2 minutes ago', type: 'SQL Injection', source: '192.168.1.100', action: 'Blocked', severity: 'high' },
    { id: 'inc2', timestamp: '5 minutes ago', type: 'DDoS Attack', source: 'Multiple IPs', action: 'Rate Limited', severity: 'critical' },
    { id: 'inc3', timestamp: '12 minutes ago', type: 'XSS Attempt', source: '10.0.0.50', action: 'Blocked', severity: 'high' },
    { id: 'inc4', timestamp: '18 minutes ago', type: 'Bot Traffic', source: '203.0.113.25', action: 'Challenged', severity: 'medium' },
    { id: 'inc5', timestamp: '25 minutes ago', type: 'Brute Force', source: '198.51.100.10', action: 'Blocked', severity: 'medium' }
  ];

  function getSeverityColor(severity: string) {
    switch (severity) {
      case 'critical': return 'text-red-600 bg-red-100 dark:bg-red-900 dark:text-red-200';
      case 'high': return 'text-orange-600 bg-orange-100 dark:bg-orange-900 dark:text-orange-200';
      case 'medium': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-200';
      case 'low': return 'text-green-600 bg-green-100 dark:bg-green-900 dark:text-green-200';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900 dark:text-gray-200';
    }
  }

  function getTrendIcon(trend: string) {
    switch (trend) {
      case 'up': return '↗️';
      case 'down': return '↘️';
      case 'stable': return '→';
      default: return '→';
    }
  }

  function getActionColor(action: string) {
    switch (action) {
      case 'Blocked': return 'text-red-600 bg-red-100 dark:bg-red-900 dark:text-red-200';
      case 'Rate Limited': return 'text-orange-600 bg-orange-100 dark:bg-orange-900 dark:text-orange-200';
      case 'Challenged': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-200';
      case 'Allowed': return 'text-green-600 bg-green-100 dark:bg-green-900 dark:text-green-200';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900 dark:text-gray-200';
    }
  }

  onMount(() => {
    // Simulate real-time security updates
    const interval = setInterval(() => {
      // Add random new incidents
      if (Math.random() < 0.3) {
        const incidentTypes = ['SQL Injection', 'XSS Attack', 'DDoS Attack', 'Bot Traffic', 'Brute Force'];
        const actions = ['Blocked', 'Rate Limited', 'Challenged'];
        const severities = ['high', 'medium', 'critical'];
        
        const newIncident = {
          id: `inc${Date.now()}`,
          timestamp: 'Just now',
          type: incidentTypes[Math.floor(Math.random() * incidentTypes.length)],
          source: `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
          action: actions[Math.floor(Math.random() * actions.length)],
          severity: severities[Math.floor(Math.random() * severities.length)]
        };
        
        recentIncidents = [newIncident, ...recentIncidents.slice(0, 9)];
      }
    }, 10000);

    return () => clearInterval(interval);
  });
</script>

<svelte:head>
  <title>Security Automation - F5 Control Center</title>
</svelte:head>

<div class="space-y-6">
  <!-- Header -->
  <div class="bg-gradient-to-r from-red-600 to-orange-600 rounded-xl p-6 text-white">
    <div class="flex items-center justify-between">
      <div>
        <div class="flex items-center space-x-3 mb-2">
          <h1 class="text-3xl font-bold">Security Automation</h1>
          <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
            Ready to Integrate
          </span>
        </div>
        <p class="text-red-100">WAF-as-Code with auto-remediation</p>
        <p class="text-red-200 text-sm mt-2">
          <strong>Requirements:</strong> F5 BIG-IP Advanced WAF (AWAF), iControl REST API
        </p>
      </div>
      <div class="flex items-center space-x-6">
        <div class="text-center">
          <div class="text-2xl font-bold">{securityMetrics.totalThreats.toLocaleString()}</div>
          <div class="text-sm text-red-100">Total Threats</div>
        </div>
        <div class="text-center">
          <div class="text-2xl font-bold">{securityMetrics.blockedThreats.toLocaleString()}</div>
          <div class="text-sm text-red-100">Blocked</div>
        </div>
        <div class="text-center">
          <div class="text-2xl font-bold">{Math.round((securityMetrics.blockedThreats / securityMetrics.totalThreats) * 100)}%</div>
          <div class="text-sm text-red-100">Block Rate</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Security Overview -->
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
      <div class="flex items-center justify-between">
        <div>
          <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Active WAF Rules</p>
          <p class="text-3xl font-bold text-gray-900 dark:text-white">{wafRules.length}</p>
        </div>
        <div class="w-12 h-12 bg-red-100 dark:bg-red-900 rounded-lg flex items-center justify-center">
          <Shield class="h-6 w-6 text-red-600 dark:text-red-400" />
        </div>
      </div>
    </div>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
      <div class="flex items-center justify-between">
        <div>
          <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Threats Blocked Today</p>
          <p class="text-3xl font-bold text-green-600 dark:text-green-400">{securityMetrics.blockedThreats}</p>
        </div>
        <div class="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
          <CheckCircle class="h-6 w-6 text-green-600 dark:text-green-400" />
        </div>
      </div>
    </div>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
      <div class="flex items-center justify-between">
        <div>
          <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Avg Response Time</p>
          <p class="text-3xl font-bold text-blue-600 dark:text-blue-400">{securityMetrics.avgResponseTime}ms</p>
        </div>
        <div class="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
          <Activity class="h-6 w-6 text-blue-600 dark:text-blue-400" />
        </div>
      </div>
    </div>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
      <div class="flex items-center justify-between">
        <div>
          <p class="text-sm font-medium text-gray-600 dark:text-gray-400">False Positives</p>
          <p class="text-3xl font-bold text-yellow-600 dark:text-yellow-400">{securityMetrics.falsePositives}</p>
        </div>
        <div class="w-12 h-12 bg-yellow-100 dark:bg-yellow-900 rounded-lg flex items-center justify-center">
          <AlertTriangle class="h-6 w-6 text-yellow-600 dark:text-yellow-400" />
        </div>
      </div>
    </div>
  </div>

  <!-- Threat Types -->
  <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
      <h2 class="text-xl font-semibold text-gray-900 dark:text-white">Threat Analysis</h2>
      <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">
        Real-time threat detection and blocking statistics
      </p>
    </div>
    <div class="p-6">
      <div class="space-y-4">
        {#each threatTypes as threat}
          <div class="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <div class="flex items-center space-x-4">
              <div class="flex-shrink-0">
                <div class="w-10 h-10 bg-red-100 dark:bg-red-900 rounded-full flex items-center justify-center">
                  <Shield class="h-5 w-5 text-red-600 dark:text-red-400" />
                </div>
              </div>
              <div>
                <h3 class="text-sm font-medium text-gray-900 dark:text-white">{threat.type}</h3>
                <p class="text-sm text-gray-500 dark:text-gray-400">
                  {threat.count} detected, {threat.blocked} blocked
                </p>
              </div>
            </div>
            <div class="flex items-center space-x-4">
              <div class="text-right">
                <div class="text-sm font-medium text-gray-900 dark:text-white">
                  {Math.round((threat.blocked / threat.count) * 100)}% blocked
                </div>
                <div class="text-sm text-gray-500 dark:text-gray-400">
                  Trend: {getTrendIcon(threat.trend)}
                </div>
              </div>
              <div class="w-16 bg-gray-200 dark:bg-gray-600 rounded-full h-2">
                <div 
                  class="bg-red-600 h-2 rounded-full transition-all duration-300"
                  style="width: {(threat.blocked / threat.count) * 100}%"
                ></div>
              </div>
            </div>
          </div>
        {/each}
      </div>
    </div>
  </div>

  <!-- WAF Rules -->
  <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
      <h2 class="text-xl font-semibold text-gray-900 dark:text-white">Active WAF Rules</h2>
      <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">
        Automated security policies protecting your applications
      </p>
    </div>
    <div class="overflow-x-auto">
      <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
        <thead class="bg-gray-50 dark:bg-gray-700">
          <tr>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
              Rule Name
            </th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
              Status
            </th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
              Severity
            </th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
              Blocks
            </th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
              Last Updated
            </th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          {#each wafRules as rule (rule.id)}
            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
              <td class="px-6 py-4 whitespace-nowrap">
                <div class="flex items-center">
                  <Lock class="h-4 w-4 text-gray-400 mr-2" />
                  <span class="text-sm font-medium text-gray-900 dark:text-white">
                    {rule.name}
                  </span>
                </div>
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                  {rule.status}
                </span>
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium {getSeverityColor(rule.severity)}">
                  {rule.severity}
                </span>
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                {rule.blocks.toLocaleString()}
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                {rule.lastUpdated}
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <button class="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 mr-3">
                  <Eye class="h-4 w-4" />
                </button>
                <button class="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300">
                  <Zap class="h-4 w-4" />
                </button>
              </td>
            </tr>
          {/each}
        </tbody>
      </table>
    </div>
  </div>

  <!-- Recent Incidents -->
  <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
      <h2 class="text-xl font-semibold text-gray-900 dark:text-white">Recent Security Incidents</h2>
      <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">
        Live feed of security events and automated responses
      </p>
    </div>
    <div class="p-6">
      <div class="space-y-3">
        {#each recentIncidents as incident (incident.id)}
          <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <div class="flex items-center space-x-3">
              <div class="flex-shrink-0">
                {#if incident.severity === 'critical'}
                  <XCircle class="h-5 w-5 text-red-500" />
                {:else if incident.severity === 'high'}
                  <AlertTriangle class="h-5 w-5 text-orange-500" />
                {:else}
                  <Shield class="h-5 w-5 text-blue-500" />
                {/if}
              </div>
              <div>
                <div class="text-sm font-medium text-gray-900 dark:text-white">
                  {incident.type} from {incident.source}
                </div>
                <div class="text-xs text-gray-500 dark:text-gray-400">
                  {incident.timestamp}
                </div>
              </div>
            </div>
            <div class="flex items-center space-x-3">
              <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium {getActionColor(incident.action)}">
                {incident.action}
              </span>
              <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium {getSeverityColor(incident.severity)}">
                {incident.severity}
              </span>
            </div>
          </div>
        {/each}
      </div>
    </div>
  </div>
</div>
