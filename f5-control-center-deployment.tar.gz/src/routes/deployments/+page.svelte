<script lang="ts">
  import { onMount } from 'svelte';
  import { circuitBreakerStore, circuitBreakerActions } from '$lib/stores/circuitBreakerStore';
  import { notificationStore } from '$lib/components/NotificationStore.svelte.ts';
  import DeploymentForm from '$lib/components/DeploymentForm.svelte';
  import DeploymentList from '$lib/components/DeploymentList.svelte';
  import type { CircuitBreakerConfig, Application } from '$lib/types';

  let config: CircuitBreakerConfig;
  let applications: Application[] = [];
  let showDeploymentForm = false;

  circuitBreakerStore.subscribe(value => {
    config = value;
    applications = value.applications;
  });

  function handleDeployApplication(applicationData: Omit<Application, 'id'>) {
    circuitBreakerActions.addApplication(applicationData);
    showDeploymentForm = false;
    notificationStore.add({
      type: 'success',
      title: 'Application Deployed',
      message: `${applicationData.name} has been deployed successfully`
    });
  }

  function handleCancelDeployment() {
    showDeploymentForm = false;
  }
</script>

<svelte:head>
  <title>Deployments - OCBC Circuit Breaker Portal</title>
</svelte:head>

<div class="space-y-8">
  <!-- Header -->
  <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
    <div>
      <h1 class="text-3xl font-bold text-gray-900 dark:text-white">Application Deployments</h1>
      <p class="mt-2 text-gray-600 dark:text-gray-400">
        Manage application deployments across circuit breaker lanes
      </p>
    </div>
    <button
      class="btn-primary mt-4 sm:mt-0"
      on:click={() => showDeploymentForm = true}
    >
      Deploy New Application
    </button>
  </div>

  <!-- Deployment Form Modal -->
  {#if showDeploymentForm}
    <div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div class="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white dark:bg-gray-800">
        <DeploymentForm 
          onDeploy={handleDeployApplication}
          onCancel={handleCancelDeployment}
        />
      </div>
    </div>
  {/if}

  <!-- Deployment List -->
  <DeploymentList {applications} />
</div>
