<script lang="ts">
  import { onMount } from 'svelte';
  import { Play, RotateCcw, AlertTriangle, CheckCircle, Activity, Zap, ArrowRight, Server, Globe } from 'lucide-svelte';

  let deployments = [
    {
      id: 'deployment1',
      name: 'OCBC Mobile Banking API',
      currentVersion: 'v2.1.0',
      newVersion: 'v2.2.0',
      status: 'running',
      blueTraffic: 100,
      greenTraffic: 0,
      blueHealth: 'healthy',
      greenHealth: 'healthy',
      blueMembers: [
        { name: 'app-server-blue-1', ip: '10.10.1.10', port: 8080, status: 'up', health: 'healthy', responseTime: 120 },
        { name: 'app-server-blue-2', ip: '10.10.1.11', port: 8080, status: 'up', health: 'healthy', responseTime: 115 }
      ],
      greenMembers: [
        { name: 'app-server-green-1', ip: '10.10.2.10', port: 8080, status: 'up', health: 'healthy', responseTime: 110 },
        { name: 'app-server-green-2', ip: '10.10.2.11', port: 8080, status: 'up', health: 'healthy', responseTime: 108 }
      ],
      metrics: {
        blueErrorRate: 0.1,
        greenErrorRate: 0.0,
        blueLatency: 120,
        greenLatency: 110,
        blueThroughput: 1250,
        greenThroughput: 1200
      },
      deploymentSteps: [
        { step: 'Deploy to Green', status: 'completed', timestamp: '2 minutes ago' },
        { step: 'Run Smoke Tests', status: 'completed', timestamp: '1 minute ago' },
        { step: 'Shift 10% Traffic', status: 'in_progress', timestamp: '30 seconds ago' },
        { step: 'Monitor Metrics', status: 'pending', timestamp: null },
        { step: 'Complete Migration', status: 'pending', timestamp: null }
      ]
    }
  ];

  let selectedDeployment = deployments[0];
  let isDeploying = false;
  let currentStep = 2; // Currently on step 3 (Shift 10% Traffic)

  function getHealthColor(health: string) {
    switch (health) {
      case 'healthy': return 'text-green-600 bg-green-100 dark:bg-green-900 dark:text-green-200';
      case 'degraded': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-200';
      case 'unhealthy': return 'text-red-600 bg-red-100 dark:bg-red-900 dark:text-red-200';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900 dark:text-gray-200';
    }
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-100 dark:bg-green-900 dark:text-green-200';
      case 'in_progress': return 'text-blue-600 bg-blue-100 dark:bg-blue-900 dark:text-blue-200';
      case 'pending': return 'text-gray-600 bg-gray-100 dark:bg-gray-900 dark:text-gray-200';
      case 'failed': return 'text-red-600 bg-red-100 dark:bg-red-900 dark:text-red-200';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900 dark:text-gray-200';
    }
  }

  function getMemberStatusColor(status: string) {
    switch (status) {
      case 'up': return 'text-green-600 bg-green-100 dark:bg-green-900 dark:text-green-200';
      case 'down': return 'text-red-600 bg-red-100 dark:bg-red-900 dark:text-red-200';
      case 'disabled': return 'text-gray-600 bg-gray-100 dark:bg-gray-900 dark:text-gray-200';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900 dark:text-gray-200';
    }
  }

  async function startDeployment() {
    if (isDeploying) return;
    isDeploying = true;
    currentStep = 0;

    // Simulate deployment steps
    for (let i = 0; i < selectedDeployment.deploymentSteps.length; i++) {
      selectedDeployment.deploymentSteps[i].status = 'in_progress';
      selectedDeployment.deploymentSteps[i].timestamp = 'Just now';
      
      // Simulate step duration
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      selectedDeployment.deploymentSteps[i].status = 'completed';
      currentStep = i + 1;
      
      // Update traffic distribution
      if (i === 2) { // Shift 10% traffic
        selectedDeployment.blueTraffic = 90;
        selectedDeployment.greenTraffic = 10;
      } else if (i === 3) { // Monitor metrics
        selectedDeployment.blueTraffic = 50;
        selectedDeployment.greenTraffic = 50;
      } else if (i === 4) { // Complete migration
        selectedDeployment.blueTraffic = 0;
        selectedDeployment.greenTraffic = 100;
        selectedDeployment.currentVersion = selectedDeployment.newVersion;
      }
    }
    
    isDeploying = false;
  }

  async function rollback() {
    if (isDeploying) return;
    isDeploying = true;
    
    // Simulate rollback
    selectedDeployment.blueTraffic = 100;
    selectedDeployment.greenTraffic = 0;
    selectedDeployment.deploymentSteps.forEach(step => {
      step.status = 'pending';
      step.timestamp = null;
    });
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    isDeploying = false;
  }

  onMount(() => {
    // Simulate real-time metrics updates
    const interval = setInterval(() => {
      if (!isDeploying) {
        selectedDeployment.metrics.blueErrorRate += (Math.random() - 0.5) * 0.1;
        selectedDeployment.metrics.greenErrorRate += (Math.random() - 0.5) * 0.1;
        selectedDeployment.metrics.blueLatency += (Math.random() - 0.5) * 10;
        selectedDeployment.metrics.greenLatency += (Math.random() - 0.5) * 10;
        selectedDeployment.metrics.blueThroughput += (Math.random() - 0.5) * 50;
        selectedDeployment.metrics.greenThroughput += (Math.random() - 0.5) * 50;
        
        // Ensure values stay within reasonable bounds
        selectedDeployment.metrics.blueErrorRate = Math.max(0, Math.min(5, selectedDeployment.metrics.blueErrorRate));
        selectedDeployment.metrics.greenErrorRate = Math.max(0, Math.min(5, selectedDeployment.metrics.greenErrorRate));
        selectedDeployment.metrics.blueLatency = Math.max(50, Math.min(500, selectedDeployment.metrics.blueLatency));
        selectedDeployment.metrics.greenLatency = Math.max(50, Math.min(500, selectedDeployment.metrics.greenLatency));
        selectedDeployment.metrics.blueThroughput = Math.max(500, Math.min(2000, selectedDeployment.metrics.blueThroughput));
        selectedDeployment.metrics.greenThroughput = Math.max(500, Math.min(2000, selectedDeployment.metrics.greenThroughput));
      }
    }, 3000);

    return () => clearInterval(interval);
  });
</script>

<svelte:head>
  <title>Blue/Green Deployment - F5 Control Center</title>
</svelte:head>

<div class="space-y-6">
  <!-- Header -->
  <div class="bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl p-6 text-white">
    <div class="flex items-center justify-between">
      <div>
        <div class="flex items-center space-x-3 mb-2">
          <h1 class="text-3xl font-bold">Blue/Green Deployment Automation</h1>
          <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200">
            Phase 2
          </span>
        </div>
        <p class="text-purple-100">Zero-downtime application updates with visual traffic shifting</p>
        <p class="text-purple-200 text-sm mt-2">
          <strong>Requirements:</strong> F5 GTM, custom iRules, advanced traffic management
        </p>
      </div>
      <div class="flex items-center space-x-4">
        <button
          on:click={startDeployment}
          disabled={isDeploying}
          class="flex items-center space-x-2 px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {#if isDeploying}
            <div class="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
          {:else}
            <Play class="h-4 w-4" />
          {/if}
          <span>{isDeploying ? 'Deploying...' : 'Start Deployment'}</span>
        </button>
        <button
          on:click={rollback}
          disabled={isDeploying}
          class="flex items-center space-x-2 px-4 py-2 bg-red-500/20 hover:bg-red-500/30 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <RotateCcw class="h-4 w-4" />
          <span>Rollback</span>
        </button>
      </div>
    </div>
  </div>

  <!-- Traffic Distribution Visualization -->
  <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
    <h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-6">Traffic Distribution</h2>
    
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <!-- Blue Environment -->
      <div class="text-center">
        <div class="flex items-center justify-center space-x-2 mb-4">
          <div class="w-4 h-4 bg-blue-500 rounded-full"></div>
          <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Blue Environment</h3>
          <span class="text-sm text-gray-500 dark:text-gray-400">({selectedDeployment.currentVersion})</span>
        </div>
        
        <!-- Traffic Gauge -->
        <div class="relative w-32 h-32 mx-auto mb-4">
          <svg class="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="40" stroke="#e5e7eb" stroke-width="8" fill="none" class="dark:stroke-gray-600"/>
            <circle 
              cx="50" cy="50" r="40" 
              stroke="#3b82f6" 
              stroke-width="8" 
              fill="none"
              stroke-dasharray={`${2 * Math.PI * 40}`}
              stroke-dashoffset={`${2 * Math.PI * 40 * (1 - selectedDeployment.blueTraffic / 100)}`}
              class="transition-all duration-1000"
            />
          </svg>
          <div class="absolute inset-0 flex items-center justify-center">
            <span class="text-2xl font-bold text-blue-600 dark:text-blue-400">{selectedDeployment.blueTraffic}%</span>
          </div>
        </div>
        
        <!-- Metrics -->
        <div class="space-y-2 text-sm">
          <div class="flex justify-between">
            <span class="text-gray-600 dark:text-gray-400">Error Rate:</span>
            <span class="font-medium">{selectedDeployment.metrics.blueErrorRate.toFixed(2)}%</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-600 dark:text-gray-400">Latency:</span>
            <span class="font-medium">{selectedDeployment.metrics.blueLatency.toFixed(0)}ms</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-600 dark:text-gray-400">Throughput:</span>
            <span class="font-medium">{selectedDeployment.metrics.blueThroughput.toFixed(0)} req/s</span>
          </div>
        </div>
      </div>

      <!-- Green Environment -->
      <div class="text-center">
        <div class="flex items-center justify-center space-x-2 mb-4">
          <div class="w-4 h-4 bg-green-500 rounded-full"></div>
          <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Green Environment</h3>
          <span class="text-sm text-gray-500 dark:text-gray-400">({selectedDeployment.newVersion})</span>
        </div>
        
        <!-- Traffic Gauge -->
        <div class="relative w-32 h-32 mx-auto mb-4">
          <svg class="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="40" stroke="#e5e7eb" stroke-width="8" fill="none" class="dark:stroke-gray-600"/>
            <circle 
              cx="50" cy="50" r="40" 
              stroke="#10b981" 
              stroke-width="8" 
              fill="none"
              stroke-dasharray={`${2 * Math.PI * 40}`}
              stroke-dashoffset={`${2 * Math.PI * 40 * (1 - selectedDeployment.greenTraffic / 100)}`}
              class="transition-all duration-1000"
            />
          </svg>
          <div class="absolute inset-0 flex items-center justify-center">
            <span class="text-2xl font-bold text-green-600 dark:text-green-400">{selectedDeployment.greenTraffic}%</span>
          </div>
        </div>
        
        <!-- Metrics -->
        <div class="space-y-2 text-sm">
          <div class="flex justify-between">
            <span class="text-gray-600 dark:text-gray-400">Error Rate:</span>
            <span class="font-medium">{selectedDeployment.metrics.greenErrorRate.toFixed(2)}%</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-600 dark:text-gray-400">Latency:</span>
            <span class="font-medium">{selectedDeployment.metrics.greenLatency.toFixed(0)}ms</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-600 dark:text-gray-400">Throughput:</span>
            <span class="font-medium">{selectedDeployment.metrics.greenThroughput.toFixed(0)} req/s</span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Pool Members -->
  <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
    <!-- Blue Pool Members -->
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
      <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
        <h3 class="text-lg font-semibold text-gray-900 dark:text-white flex items-center">
          <div class="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
          Blue Pool Members
        </h3>
      </div>
      <div class="p-6">
        <div class="space-y-3">
          {#each selectedDeployment.blueMembers as member}
            <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <div class="flex items-center space-x-3">
                <Server class="h-4 w-4 text-gray-400" />
                <div>
                  <div class="text-sm font-medium text-gray-900 dark:text-white">{member.name}</div>
                  <div class="text-xs text-gray-500 dark:text-gray-400">{member.ip}:{member.port}</div>
                </div>
              </div>
              <div class="flex items-center space-x-2">
                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium {getMemberStatusColor(member.status)}">
                  {member.status}
                </span>
                <span class="text-xs text-gray-500 dark:text-gray-400">
                  {member.responseTime}ms
                </span>
              </div>
            </div>
          {/each}
        </div>
      </div>
    </div>

    <!-- Green Pool Members -->
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
      <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
        <h3 class="text-lg font-semibold text-gray-900 dark:text-white flex items-center">
          <div class="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
          Green Pool Members
        </h3>
      </div>
      <div class="p-6">
        <div class="space-y-3">
          {#each selectedDeployment.greenMembers as member}
            <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <div class="flex items-center space-x-3">
                <Server class="h-4 w-4 text-gray-400" />
                <div>
                  <div class="text-sm font-medium text-gray-900 dark:text-white">{member.name}</div>
                  <div class="text-xs text-gray-500 dark:text-gray-400">{member.ip}:{member.port}</div>
                </div>
              </div>
              <div class="flex items-center space-x-2">
                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium {getMemberStatusColor(member.status)}">
                  {member.status}
                </span>
                <span class="text-xs text-gray-500 dark:text-gray-400">
                  {member.responseTime}ms
                </span>
              </div>
            </div>
          {/each}
        </div>
      </div>
    </div>
  </div>

  <!-- Deployment Steps -->
  <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
      <h2 class="text-xl font-semibold text-gray-900 dark:text-white">Deployment Progress</h2>
      <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">
        Automated deployment pipeline with health checks and traffic shifting
      </p>
    </div>
    <div class="p-6">
      <div class="space-y-4">
        {#each selectedDeployment.deploymentSteps as step, index}
          <div class="flex items-center space-x-4">
            <div class="flex-shrink-0">
              {#if step.status === 'completed'}
                <CheckCircle class="h-6 w-6 text-green-600" />
              {:else if step.status === 'in_progress'}
                <div class="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
              {:else}
                <div class="w-6 h-6 border-2 border-gray-300 rounded-full"></div>
              {/if}
            </div>
            <div class="flex-1">
              <h3 class="text-sm font-medium text-gray-900 dark:text-white">{step.step}</h3>
              {#if step.timestamp}
                <p class="text-xs text-gray-500 dark:text-gray-400">{step.timestamp}</p>
              {/if}
            </div>
            <div class="flex-shrink-0">
              <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium {getStatusColor(step.status)}">
                {step.status.replace('_', ' ')}
              </span>
            </div>
          </div>
        {/each}
      </div>
    </div>
  </div>
</div>
