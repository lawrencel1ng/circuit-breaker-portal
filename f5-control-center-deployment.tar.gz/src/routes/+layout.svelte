<script lang="ts">
  import '../app.css';
  import { onMount } from 'svelte';
  import { page } from '$app/stores';
  import { circuitBreakerStore } from '$lib/stores/circuitBreakerStore';
  import Navigation from '$lib/components/Navigation.svelte';
  import NotificationContainer from '$lib/components/NotificationContainer.svelte';

  let darkMode = false;

  onMount(() => {
    // Load dark mode preference
    const savedDarkMode = localStorage.getItem('darkMode');
    if (savedDarkMode !== null) {
      darkMode = savedDarkMode === 'true';
    } else {
      darkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    updateDarkMode();
    
    // Load circuit breaker configuration
    circuitBreakerStore.loadConfig();
  });

  function updateDarkMode() {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('darkMode', darkMode.toString());
  }

  function toggleDarkMode() {
    darkMode = !darkMode;
    updateDarkMode();
  }
</script>

<div class="min-h-screen bg-gray-50 dark:bg-gray-900">
  <Navigation {darkMode} {toggleDarkMode} />
  
  <main class="container mx-auto px-4 py-8">
    <slot />
  </main>
  
  <NotificationContainer />
</div>
