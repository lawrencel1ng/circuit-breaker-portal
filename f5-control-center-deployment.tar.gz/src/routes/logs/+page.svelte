<script lang="ts">
  import { onMount } from 'svelte';
  import { circuitBreakerStore } from '$lib/stores/circuitBreakerStore';
  import LogViewer from '$lib/components/LogViewer.svelte';
  import type { CircuitBreakerConfig } from '$lib/types';

  let config: CircuitBreakerConfig;

  circuitBreakerStore.subscribe(value => {
    config = value;
  });
</script>

<svelte:head>
  <title>Automation Logs - OCBC Circuit Breaker Portal</title>
</svelte:head>

<div class="space-y-8">
  <!-- Header -->
  <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
    <div>
      <h1 class="text-3xl font-bold text-gray-900 dark:text-white">Automation Logs</h1>
      <p class="mt-2 text-gray-600 dark:text-gray-400">
        Monitor system automation, configuration changes, and operational events
      </p>
    </div>
  </div>

  <!-- Log Viewer -->
  <LogViewer {config} />
</div>
