<script lang="ts">
  import { onMount } from 'svelte';
  import { circuitBreakerStore } from '$lib/stores/circuitBreakerStore';
  import LoadBalancerConfig from '$lib/components/LoadBalancerConfig.svelte';
  import GSLBConfig from '$lib/components/GSLBConfig.svelte';
  import type { CircuitBreakerConfig } from '$lib/types';

  let config: CircuitBreakerConfig;

  circuitBreakerStore.subscribe(value => {
    config = value;
  });
</script>

<svelte:head>
  <title>Configuration - OCBC Circuit Breaker Portal</title>
</svelte:head>

<div class="space-y-8">
  <!-- Header -->
  <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
    <div>
      <h1 class="text-3xl font-bold text-gray-900 dark:text-white">Configuration Manager</h1>
      <p class="mt-2 text-gray-600 dark:text-gray-400">
        Manage Load Balancer and GSLB configurations across all lanes
      </p>
    </div>
  </div>

  <!-- Load Balancer Configuration -->
  <LoadBalancerConfig {config} />

  <!-- GSLB Configuration -->
  <GSLBConfig {config} />
</div>
